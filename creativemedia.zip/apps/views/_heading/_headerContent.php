<section class="content-header">
    <h1>
        <?php echo @$judul; ?>
        <small><?php echo @$deskripsi; ?></small>
    </h1>
    <ol class="breadcrumb">
        <li class="active"><?php echo @$page; ?></li>
        <li class="active"> Here </li>
    </ol>
</section>

