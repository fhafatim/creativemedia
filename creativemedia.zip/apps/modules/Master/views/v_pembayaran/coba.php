<?php $this->load->view('_heading/_headerContent') ?>
<input type="text" name="created_by" value="<?php echo $datamaster->id_pembayaran; ?>">
<input type="text" name="created_by" value="<?php echo $datamaster->nama_siswa; ?>">

<P class="p6 ft4">: <?php echo $data_master->nama_siswa;?></P>