<html>

<head>
    <title>Aktivasi</title>
</head>

<body>
    Selamat datang Akun Anda Sudah Aktif
    <!-- variable nama adalah array dengan nama = 'nama' menghasilkan variable di view dari controller tadi.-->
    <a href="login/logout">Login</a> <!-- link untuk logout -->
</body>

</html>