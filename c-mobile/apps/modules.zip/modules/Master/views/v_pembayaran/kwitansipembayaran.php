<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN" "http://www.w3.org/TR/html4/strict.dtd">
<HTML>

<HEAD>
    <META http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <TITLE>pdf-html</TITLE>
    <META name="generator" content="BCL easyConverter SDK 5.0.252">
    <META name="author" content="Asus">
    <STYLE type="text/css">
    body {
        margin-top: 0px;
        margin-left: 0px;
    }

    #page_1 {
        position: relative;
        overflow: hidden;
        margin: 26px 0px 558px 36px;
        padding: 0px;
        border: none;
        width: 780px;
    }

    #page_1 #id1_1 {
        border: none;
        margin: 14px 0px 0px 3px;
        padding: 0px;
        border: none;
        width: 777px;
        overflow: hidden;
    }

    #page_1 #id1_2 {
        border: none;
        margin: 31px 0px 0px 16px;
        padding: 0px;
        border: none;
        width: 764px;
        overflow: hidden;
    }

    #page_1 #id1_2 #id1_2_1 {
        float: left;
        border: none;
        margin: 4px 0px 0px 0px;
        padding: 0px;
        border: none;
        width: 552px;
        overflow: hidden;
    }

    #page_1 #id1_2 #id1_2_2 {
        float: left;
        border: none;
        margin: 0px 0px 0px 0px;
        padding: 0px;
        border: none;
        width: 212px;
        overflow: hidden;
    }

    #page_1 #id1_3 {
        border: none;
        margin: 58px 0px 0px 568px;
        padding: 0px;
        border: none;
        width: 212px;
        overflow: hidden;
    }

    #page_1 #p1dimg1 {
        position: absolute;
        top: 0px;
        left: 0px;
        z-index: -1;
        width: 757px;
        height: 445px;
    }

    #page_1 #p1dimg1 #p1img1 {
        width: 757px;
        height: 445px;
    }

    .dclr {
        clear: both;
        float: none;
        height: 1px;
        margin: 0px;
        padding: 0px;
        overflow: hidden;
    }

    .ft0 {
        font: 11px 'Calibri';
        line-height: 13px;
    }

    .ft1 {
        font: 1px 'Calibri';
        line-height: 2px;
    }

    .ft2 {
        font: 1px 'Calibri';
        line-height: 1px;
    }

    .ft3 {
        font: bold 25px 'Calibri';
        line-height: 21px;
    }

    .ft4 {
        font: 14px 'Calibri';
        line-height: 17px;
    }

    .ft5 {
        font: italic 14px 'Calibri';
        line-height: 17px;
    }

    .ft6 {
        font: 14px 'Calibri';
        text-decoration: underline;
        line-height: 17px;
    }

    .ft7 {
        font: bold 12px 'Arial';
        line-height: 15px;
    }

    .ft8 {
        font: bold 20px 'Calibri';
        line-height: 24px;
    }

    .ft9 {
        font: bold 14px 'Calibri';
        text-decoration: underline;
        line-height: 17px;
    }

    .p0 {
        text-align: left;
        padding-left: 360px;
        margin-top: 0px;
        margin-bottom: 0px;
    }

    .p01 {
        text-align: left;
        padding-left: 370px;
        margin-top: 0px;
        margin-bottom: 0px;
    }

    .p1 {
        text-align: left;
        padding-left: 498px;
        padding-right: 24px;
        margin-top: 3px;
        margin-bottom: 0px;
        text-indent: 2px;
    }

    .p2 {
        text-align: left;
        margin-top: 0px;
        margin-bottom: 0px;
        white-space: nowrap;
    }

    .p3 {
        text-align: center;
        padding-right: 137px;
        margin-top: 0px;
        margin-bottom: 0px;
        white-space: nowrap;
    }

    .p4 {
        text-align: center;
        padding-right: 138px;
        margin-top: 0px;
        margin-bottom: 0px;
        white-space: nowrap;
    }

    .p5 {
        text-align: left;
        padding-left: 3px;
        margin-top: 0px;
        margin-bottom: 0px;
        white-space: nowrap;
    }

    .p6 {
        text-align: left;
        padding-left: 14px;
        margin-top: 0px;
        margin-bottom: 0px;
        white-space: nowrap;
    }

    .p7 {
        text-align: left;
        padding-left: 13px;
        margin-top: 0px;
        margin-bottom: 0px;
        white-space: nowrap;
    }

    .p8 {
        text-align: left;
        margin-top: 0px;
        margin-bottom: 0px;
    }

    .p9 {
        text-align: left;
        padding-left: 7px;
        margin-top: 2px;
        margin-bottom: 0px;
    }

    .td0 {
        border-top: #000000 1px solid;
        border-bottom: #000000 1px solid;
        padding: 0px;
        margin: 0px;
        width: 118px;
        vertical-align: bottom;
    }

    .td1 {
        border-top: #000000 1px solid;
        border-bottom: #000000 1px solid;
        padding: 0px;
        margin: 0px;
        width: 21px;
        vertical-align: bottom;
    }

    .td2 {
        border-top: #000000 1px solid;
        border-bottom: #000000 1px solid;
        padding: 0px;
        margin: 0px;
        width: 615px;
        vertical-align: bottom;
    }

    .td3 {
        border-bottom: #000000 1px solid;
        padding: 0px;
        margin: 0px;
        width: 118px;
        vertical-align: bottom;
    }

    .td4 {
        border-bottom: #000000 1px solid;
        padding: 0px;
        margin: 0px;
        width: 21px;
        vertical-align: bottom;
    }

    .td5 {
        border-bottom: #000000 1px solid;
        padding: 0px;
        margin: 0px;
        width: 615px;
        vertical-align: bottom;
    }

    .td6 {
        padding: 0px;
        margin: 0px;
        width: 118px;
        vertical-align: bottom;
    }

    .td7 {
        padding: 0px;
        margin: 0px;
        width: 21px;
        vertical-align: bottom;
    }

    .td8 {
        padding: 0px;
        margin: 0px;
        width: 615px;
        vertical-align: bottom;
    }

    .td9 {
        padding: 0px;
        margin: 0px;
        width: 636px;
        vertical-align: bottom;
    }

    .td10 {
        border-top: #000000 1px solid;
        padding: 0px;
        margin: 0px;
        width: 118px;
        vertical-align: bottom;
    }

    .tr0 {
        height: 2px;
    }

    .tr1 {
        height: 21px;
    }

    .tr2 {
        height: 1px;
    }

    .tr3 {
        height: 17px;
    }

    .tr4 {
        height: 31px;
    }

    .tr5 {
        height: 19px;
    }

    .tr6 {
        height: 20px;
    }

    .tr7 {
        height: 18px;
    }

    .tr8 {
        height: 36px;
    }

    .t0 {
        width: 754px;
        margin-top: 11px;
        font: 14px 'Calibri';
    }
    </STYLE>
</HEAD>

<BODY>
    <DIV id="page_1">

        <!-- <input type="text" name="created_by" value="<?php echo $datamaster->id_pembayaran; ?>"> -->
        <input type="hidden" name="created_by" value="<?php echo $data_master->id_pembayaran; ?>">
        <DIV id="p1dimg1">
            <IMG src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAvUAAAG9CAIAAAAawx5GAAAgAElEQVR4nOzdd3gURQPH8bmSXkiBNAIBQu9ISQgtdKR3QTqoIEVEwAZWQKQKCCpSLCCi0qRJEJAqLaH3GkogBVJIT668f2ze40guyeVyiC7fz+Pjszs3OzsXHszP2dkZhV6vFwAAADKifNYdAAAAsDK14UihUDzDfgAAAFiLgudTAABAZhi/AQAAcsP4DQAAkBvmFwMAALlRF17lKbtw6sT9U4eUdy64xt/2TI221WdnKu0e2bsnuJW1bdSpZrPWrq6uz7qPAADgv+TZPJ/a++sPpfd87ZP10PxLrrpWrPrZekdHx6fXKwAAIA//XL45uPm3mhvfV1ljEnOiyqnMslNWaAgAAMjRP5Fvdi38KOj0Gqs3e9OpbLX5O2xsbKzeMgAA+E97uvnm1Pi2gcmRT699yRnvBk1m/vw0Wr568fztv/8UD+/q7Z1r9HrVt3TpvHVO/r3f5LVqW7uylaqWKFHC5Kenjx7SabXm9KFeSPP8PjK+tcrGtnbDYONPz0UcS3kYZ84thBC2Ts4vNGlx5vgRbXaW8a21Wu2Zo4cMJS4eJStWrW6yhdiYmKjrl3N1O78fTl4FfE0AAIrqaeWbiAN/Vf7utafRskl3HXyqLTlgxQZ3fTE16OwvectvOgdUnbvd1tbWUJI8vFLBTV30qNFwzsZcywvFvFLDUZeV3yXGXFZeNVl+6ezp0l/0LqDmwSkD69w/as4thBCRTmVqfbnn5siGJbMTczWY6wvm15/IkQ08s5MKvrYA+TULAIAFnsr74cnDK/2T4UYI4Z8enTy8UswI00MLRRL1Sp3k4ZVMhhshRPmUW5mjapj/a1sIUS3+fMqIyjHDrdA3Y7nCjRDi9Ph21r2F5OrwZcanJodkMjMzjcPNg/e3P42eAABgJivnG71enzSsonXbNJ+jPjt5eKXY6GiLW4gbUc1Vl2ZOzV2LPipSy44ie8+McRZ1yoQjO7flLayQfNNa7Rt7oWmo8an7D2/lrfP3nCcKy1csQv4DAMDqrLn+TVZWVuaoGspnvc+Dw/vNhEUPO/R6vb1eY1ySqHKKG7Kgbkjz9PT0O5M7lM54nJzavPFJ3haOt5rYauAow+neX3+ov2O64bTh9R353bqoT2eq/vymMPVj3rVsXptXJ0rHTWeszvWp8bCTeskZBwcHw2mtAm931rt+rZgI6dh4nMagwY2dhuNjVbu1NtXINZfy9RbuNPUJAABWZrXxm92zJmaOqmGt1oopeXilxISEol6VMqKy8anLyqtllp16oWmoUql0cnKq+tUBl5VXjwa9JsyOI6F9h+SqefH0yaL2yqQnXrNfeMJwGHT4G6u0n0vIzLXGp39NG1NA5dZvz30afQAAwHxWyzeNLm+2VlPFd6xqNzd39yJdEvPkU60LnjVNVmszcrLjsksWdyzx/h2LrzU4vvdPw3Gqws7FxcX4011fTC3+LQrW4OYTwzAWREkAAJ4qKzyf0uv1uUY+nq0klaMFQwg35402Hn0KmrMxv5oqlcqifgkhhH+12ibL85uwbHKgqOqPow3H3svPCiGy9QobRc57cEFnfxFiet6riulEmRYv3Nln8iPtxMaGn8jRRiPa5NNCxeSbRfqaAABYzAr5JvaVmsXcNGFrtMs3N9wuJj+xUp9CiHerJIwol1DU6Tz+y05b0IeyidcsuKpQ+z8YVs/otExAuWI2uPeX7+r//zhTqFwUCiHEhV4z62x4t5gtF6zJB9+kv1bNcJqYkGAYIbMVjxfyaTPq6XYDAABzFDff3Hu1toverHVc8nrrjPfv953y+1QvxMzL7jMv5/wSfbtywsjyhTwHibL3qfqVhavgpCvtXLTpll1r0HDPvOQ984xLjMPN0eCR+Y1tmK9+2GeGY7dvz0kHTTv3SjbKNxfHNLPuakBCCLVafcGzZvWHOXfUTmwsVl4SQhyb1N2Qeo7W6F38LwgAQPEVK9+cDT9azqJMcCzBof8x3yJdMvuK+8Z7zjua5Dt/RaNXWBxuhBC3/Rt63Xw8r0Wn0ymV1nx5PlHl3Oa1Sfl9GhHQymR56JOnu5ZMD/r/sVYv1OrHf3zHQyc03PuFdOyfbvkb8gWo/uGPYvwL0rFhzKZa/HlDhTYTZxZweZLK8Zp/sMmPQq3TQQAAclieb/R6fbmvBlpwYWBYBcvueDXFJjCsgkohLrW9oXzyqdVJTanmP/5tWbOS0KlLjGcRpb5SJb9JIXduRRb1MZPT8ssuBaal0I+WFtqIXq8PivjBcKpSPDFrp+GTlSNHNii3NLxInSyUi4vLOcfSAWlR0umxSd2TqzZv9P9Pwyu0a1ng5XGO3uZ8TQAAis/yIYpDUywJNy0PlLX4jhKtXlTamTsh9d7tMnDwxOI0q1AossQTE4evnD+bt9rt1+q5fdI2IT7eZCMnSzc91vwN6R/j8r9++LI4fZPsnV7QW9m5mFylpvhKvv94n9Rq8ecb/f214TR0yuKncUcAACxg+fhNnehj5le+nWYz4LjfvYzC3zxydbFzdLKLj0/Nyipo+8nAsAo7m94NdMoSQlQMqyCE2Ln7nFfp9hfPrPH09DS/Y8Y8V14yHhHxndczWQghxFXXQOfMZN/MWCGENBtIPSlI8+1F48dDEk2VoNb/X9/vSsOWvvN6SMeNDiw+VMq/Sede+d36cNiW/D4qXaVm2XLlhRANjB6fmSP6lZo+y88V6ZJC+fj5Rdq4eRrtUSU57RfctLB1HR2yUwv4mtWDm+e3FykAAEVlzfWLTTqdZN/ziF+h1Sa92fXtybnHJ1JSUvoPnHT0uOltB9od9D/Z6la7Q/7GG4RWq/1y+OFlZctaOEp0yb1a1YSLuQorPbqet+aJA3satSxov6fKNWo+FEpboZNOa294V+Sfb2r+YmLTA0l423fLlhuRqzC/Z2d/TRttiEFOukyrzyISQmS9sVLM65mrsNGHKwq9sHRGbOn8v2aU37oSteoUt3MAAAghLH4+tW/dqoIraPSK0ad8AsMq9Dzi19c/ZXPjqPxqTnmnd2xUWN5wI4Rwdnbesumb2KiwwAolTV5bb09AXGbuMaEGjV8trPv5ajhv84kyzQutdr5k7YLDjSTjkydGXIqz/+WemePNqdbiyYdEBz6x/EeRn8o1TOzlYLyhOgAAz5yF+eaF7Z+aLI9IdKizu3xgWIVau8r1KZ18vf2N6+1vzKwR2/Vw6byV9Xp9zN0d498o/Hfw4QM/xUaFmd89r9Ltd+/ea359Yy0+WeGy8mr0JBPr+0XbeiZP+8tl5dXg2evNaap0mbJH6w0ynFZIvnnw/QEWdEmj0TS8+nhH7hOd8t3aU6lUnvN6wXD6wp39WVkWvr1fgCvDvjU+TVY55FcTAIBnQqHX6wuvlUfehWhfO+m7O9ZBCOFqozvRKtJ4LsbHF0utuu0i8oi5u0NRlM049+490HdAEVbm/XL+qJde6mF+fZNSUlLiou97enm7uroWsykAAPDPsCTf7Fu3Shq/ORrv8MoJnzStQgjxQ4Popp5pJuubfCG8SOMxBvfv36/TYKj59fV6fdw99qwGAOD5Ysn8YlXEH9ujXcadLiWEcLfRrW10v4ZrRpFa+G3NBxbcVwjh6+vr51fi3j1zX35WKBRepdtblqUAAMB/VBHGb7ZtD3tl5BdanV4I0d0vdV6tGDMvzDV+4+Jse/1yvu8Jm8OrdPuiXhJ5daOjYzG3yQIAAP8NZo3f/Pzz+vGTlgqRM1fmevsb5t/gbrpNrpLpHw81/3KTbG1VBa+Ok1e5Sj0unf3Zw8MjvwoLFn4bH//IcDpieJ+AgID8Kn/40RP7k3/6Sc7GCz+u+iU21vTSf7lMmvi6dPDFgqVarS5vBYVCNG78QuPgRvlNUdJqtV8seDzPd+Jbo/Kruf/AoWPHzhhO35ow0uovjQMA8K+S7/iNRqMJqNglO9vEr94i5Zu1d12nnH/i7e7iPy1a+u0PH3yypvB6efj5lTh1/FeTHzUI6nf77hP7d+bXz8o1uiUmZpis2aL1kIuXzNr7yXCJb9kOWm3hQ2ivDW89fdrbxiWZmZllKnQ1nN6/vV2lMr18Yq7hLqVSRN/hgR0AQM5M/H/8T2vWeZVu5xfQyWS4KarErMLXLC6q2rWrFV7JlHv3kk6cOFWcW2u12lzh5p/x7crdq3/6zSpN6XQiMzPTKk0BAPDvlDvfNGk+cMLkZYZHUcVn+xSehNjb2Vl8bafu75pZc8+efXkLu/YYbfGti+mtt5dv3LS1qFf98OPavIXdehZhKysAAP5zcs+/ObR/tXQQFRVVr9Hw4t+gehFfrTLHob8t3Bnbw93x0jkTC/eZ1G/QZ7FRLYxLbt26dTwi0vzbFfVJnEqluH97h3HJlq07Roz8wnA6csyXGemZ/fvnu89DXpPf+y5v4YlTd5KSktjvCQAgV/mOrpQuXTo2Kuzaxd/q1vYvzg3quuV+FHLlium9k8y3buMBC66qUL6k+eFGMuOzhcanLduOteC+xdGlc4ejB5cal4yf9G1+lfMy7n+zkEo+Po+XKGzf6fXidw8AgH+nQp4eubq67vxjRWxUWGxU2Ptv5wwbBIZVWBnpZuYN7JW5J/G07mDWVkoFuHDxflEvuXNj85GDP5lZuV+fYOlg4ZLtOl1O/3/7bVNKas5eB/Z2T31fUoPy5cstXfKGccnfh4+aee3CJY93dVj/2+IzEY9n8Ny4+fDevXvW6CAAAP86RZgd8+b412Kjwm5cXl83wHHGZY/AsApzrnhacMvMTK0hNFjg81mLC6/0pJi7O+yKMmXngymPx2m698yZcDPmza8Nhdt+n2VOO16l25v8x/yeSHp072R8un7Dn/nVNPb6mKmG49o1Tez/1b7TG3kLAQCQgSLP/nV2dp678B1p40xPO21gWAXpn9jMfIc0bPLcxKfMi0W9r+TSpcvzFxVhbUBbW1VsVFiRdrmSzJs1Qjo4cvzmnTt3jD/y8ytRq1bNojZoRWfP3Sy0TnZ29vpNxw2nu8JWSgflyj5eASgmNtnqfQMA4N/AkrebajfMeXwzPCDxevsb59pENvbIaLy3bGBYhZmXS+at/1VdEysdN276sgW3bt66CEMO7u4Od29uL7yeKYMG9jUct2g9evacJYbTPWHfWNamtZQsWfi84J69xxmOK5R//Iey4bc5xtVSUlKs2DEAAP4lLJxHotEr1IqcVekcVLrVDXNmcqy6XULajSHAUfNTw/u+9tlCiFalUn3ttfcznlgI5/rNh16l29+9ucXW1tbMmxbpyc6F0z+VLGkibFkgJTVr7oLN0nFIUIUCFkHOxVr7Xu3bd9D4dPy4QqJhQkLC0fDHYzx1a5cbNXqKyZoVqvRicy4AgPxYuDpNRNAIk+WDyiZdb39jUZ24u+nqpvvKBIZVmHappBBiX/PbJuv7l+9izu1iYmKKFG5uX/+9+OFm/uxX8hau/63Is3+Kr8/LnxqfBjVqUHD9th2eeDdqw+/hxv/kqhwbG2uVTgIA8O9hYb5pPfLtAj7t5JN8pd2Nq+1udPdL/f6Wa2BYhYlnvYYFmJ7t4VW6/fQnX8M2ptFomoUOqvXCYNPX2pnYhWrUK23t7e0L7L5ZBg7ok6vE0cEmvz0Qnp7uPV83Xm6xcsVShV6Sa6OJgrXr9E+/9A4AwNNm4fMpc2bsKhViXq2YebWEECIsxvmN01751Vy0ZPui/7/JrNfrlUqFOZuaHw697WWnEUJU2llBpxdCCBsbZVTkH+b030y/r5/WrdcHhtPIa0VbPnjqB7Pz+6hRo1pdu+SeZK3V6oeNyAmOOq3ujz/P5qrg7u5wcN/qgm+anFy0WcP37iVdv34jMLBC4VUBAPiPsHwdl4dqV0/No8LrCSGEaO+dcrldil6ICWe8t9x3KqCmQmFWuLna7qby/xOArra7ERhWwc3N/sr5383sj5kaBzcyHJfxN3fJH4NvV+7O76P0jMy8+UYIsW3H6fwuUakUl89tKvSm7TuOMj7Nb3qN8fO+Dl0mXL1g5R8dAADPkOW7Q5X7NqKolyiEWFA75ocGZu2wnZ/pNR5eb3/DEG4kl9rdtHq4kUhrG8ZGhUUc/eVptG+mD9/vm2vrBpNu3bp17cYDw+mJoyvyqzlz2uNHfklJGeHhJ4rZQwAA/j2Ktfvl0epF2AjJoKln2pV2Nx1UZozSPKmeW+b19jf6+yfl/chGob//Si0LOvMvV62qz/pfPoqNChs7xvSE7lzadnzi/Xl//3z31hgxfIDxaY++U/OrCQDAf45Cb87ToPxdGNO8THqRd0swuJhs1/lvE0vrGvOz165qeL+cY5Y5DabN2O/t62txfwAAgAwUN98IIZKHVypmCxq94qc7rr/fczmdlLMWjq1SH+SROatmnLdddlFbU355ysmpoCk+AABA3qyQb4Q1Io51Oa+4YsGeDAAAQB6KNf/G4OEUa76VXXwpIyo/6y4AAIBnxjr5plxgxaO1XrJKU1ZxtPHIZ90FAADwzFgn3wgh2kyYfsK/qbVaK45MoWrz6iQLLlSr1c7Ozvv37xdPvnlk/KjLcJydnV2zZs2QkBAHB4cHDx4MHz48JCTE3d09JCTEUPngwYPZ2dk6nS4gIEAqGTp0qBDi/PnzHh4e5cqV69WrlxCifv36Qojbt2+HhITUq1fvhRdekCr7+PiEhISEhITs2rXLZIcVCoVUQQgRHx8/c+ZMIUR4eM4ODFWrVg0JCZGWcr579+6DB4/fGy9TpkzLli3t7Oyk0969e4eEhAQFBf39999CiKioqIYNG4aEhLz88hMbXZUuXbpVq1Z2dna3b98WQri7uxt/2r1795CQEC8vr+bNm0u3aNiwobTc8zfffGPcYXt7+5MnT0olIf+Xz58JAACWsHx9v7xafPrdX5+OahCZ76J2/4A7Dr7Vl+y34MJt27bFxMR4enoaSh48eFCyZMm5c+f27NlTKhk4cODVq1cvXbpUtWpVIcQ333zTtGlTIYSvr+/9+/eFEB07dty+3cSO5RMmTPjyyy/HjcvZ03vw4MHx8fF5q0nxQq/Xt2jRYt++fT169Pj6668L7rZ0iRDCw8Pj/v37qampw4cPP3PmjBBi5syZPXr0kBo0vqRkyZKGrNOvX7+1a9ca2nFyckpNTRVC/PHHH7k28HJzc0tMTJSOGzdufPjw4Vw92bRpkxBi2LBh3333nRCib9++8+bNy6/DL7300i+//GLcfwAArMhq4zeSlh9+47LyqnXbNNMDGzeXlVctCzdCiE6dOnl6etaoUeP06ZwVhLt165aamlquXDlpECI1NXXw4MEVK1bs37+/VGHNmjVz5sxp2bLltm3bCm78hRdeePnll4cNGyadRkREZGZmDh8+/JVXTGzhqVAojh07JoSIjIzcvHnz5s2bC2jZuMLChQsDAgIMAWvTpk1z5swJDQ3NNdW6cuXHk5N+/fVX6WDOnDmff/65NAIkhNixY8fmzZuNQ5g0yCRZvbqQPSKEEPPmzdu5c6dhiCiXH3/88ejRo4b+k3IAANZlzfEbA/2CCMWb9QuvZz0R7d8PfWlYcVr4448/XnzxxfPnz/fs2XPDhg1CiIMHDyqVSr1eL4WAhg0bvvfee6tWrXrrrbfWrl3bq1evl19+uWnTpsuWLTM8USqAp6dnhQoVdu7cKYTYuHFjjx49Vq5cqVAoli9fnqtmdHT0G2+8IYQoV65c165dC27WuEKJEiUePXrk7u6ekJAghOjevXuPHj0mT56c6xI7O7v09HQHBwchxPz586VCqZphpKdDhw65xm/S0tIyMzOlvFK/fv3ExMQXX8zZXyI+Pt7Dw8O4ckpKirOzc7t27SIiTC9yXb169evXr+fqPwAA1mKd98NN0uv1t0Y19Mw2sdywFR2tN6jNuA+t3qxOp1Mqcwa39Hq9QqGQ/p33U+NT4zomGSpIP3bDsXSg0+kUCoXxXaQD40KNRqNWq3NVkHJYrlvnKpEqG7qdkZFh2GXduANSBeOWjds0vkqSlpbm6Oho8qaGysbt52ozvxsBAFAcTzHfSK5fvug166n8P/pJv5Dm0394Gi0DAID/tKeebwx2LZkeFGGFOHLLyd/v43UeRhOBAQAAjP1z+UaSmJCQMamZkz7TgmvP918Y3Laj1bsEAABk5p/ON3mF79uVeOG4zf2rro/uOWcmCSFS7VyTSvhrytYKeukVZ2fnZ9s9AADwn/Ps8w0AAIB18dIKAACQG/INAACQG/INAACQG/INAACQG/INAACQG/INAACQG/INAACQG/INAACQG/INAACQG/INAACQG/INAACQG/INAACQG/INAACQG/INAACQG/INAACQG/INAACQG/INAACQG/INAACQG/INAACQG/INAACQG/INAACQG/INAACQG/INAACQG/INAACQG/INAACQG/INAACQG/INAACQG/INAACQG/INAACQG/INAACQG/INAACQG/INAACQG/INAACQG/INAACQG/INAACQG/INAACQG/INAACQG/INAACQG/INAACQG/INAACQG/INAACQG/INAACQG/INAACQG/INAACQG/INAACQG/INAACQG/INAACQG/INAACQG/INAACQG/INAACQG/INAACQG/INAACQG/INAACQG/INAACQG/INAACQG/INAACQG/INAACQG/INAACQG/INAACQG/INAACQG/INAACQG/INAACQG/INAACQG/INAACQG/INAACQG/INAACQG/INAACQG/INAACQG/INAACQG/INAACQG/INAACQG/INAACQG/INAACQG/INAACQG/INAACQG/INAACQG/INAACQG/INAACQG/INAACQG/INAACQG/INAACQG/INAACQG/INAACQG/INAACQG/INAACQG/INAACQG/INAACQG/INAACQG/INAACQG/INAACQG/INAACQG/INAACQG/INAACQG/INAACQG/INAACQG/INAACQG/INAACQG/INAACQG/INAACQG/INAACQG/INAACQG/INAACQG/INAACQG/INAACQG/INAACQG/INAACQG/INAACQG/INAACQG/INAACQG/INAACQG/INAACQG/INAACQG/INAACQG/INAACQG/INAACQG/INAACQG/INAACQG/INAACQG/INAACQG/INAACQG/INAACQG/INAACQG/INAACQG/INAACQG/INAACQG/INAACQG/INAACQG/INAACQG/INAACQG/INAACQG/INAACQG/INAACQG/INAACQG/INAACQG/INAACQG/INAACQG/INAACQG/INAACQG/INAACQG/INAACQG/INAACQG/INAACQG/INAACQG/INAACQG/INAACQG/INAACQG/INAACQG/INAACQG/INAACQG/INAACQG/INAACQG/INAACQG/INAACQG/INAACQG/INAACQG/INAACQG/INAACQG/INAACQG/INAACQG/INAACQG/INAACQG/INAACQG/INAACQG/INAACQG/INAACQG/INAACQG/INAACQG/INAACQG/INAACQG/INAACQG/INAACQG/INAACQG/INAACQG/INAACQG/INAACQG/INAACQG/INAACQG/INAACQG/INAACQG/INAACQG/INAACQG/INAACQG/INAACQG/INAACQG/INAACQG/INAACQG/INAACQG/INAACQG/INAACQG/INAACQG/INAACQG/INAACQG/INAACQG/INAACQG/INAACQG/INAACQG/INAACQG/INAACQG/INAACQG/INAACQG/INAACQG/INAACQG/INAACQG/INAACQG/INAACQG/INAACQG/INAACQG/INAACQG/INAACQG/INAACQG/INAACQG/INAACQG/INAACQG/INAACQG/INAACQG/INAACQG/INAACQG/INAACQG/INAACQG/INAACQG/INAACQG/INAACQG/INAACQG/INAACQG/INAACQG/INAACQG/INAACQG/INAACQG/INAACQG/INAACQG/INAACQG/INAACQG/INAACQG/INAACQG/INAACQG/INAACQG/INAACQG/INAACQG/INAACQG/INAACQG/INAACQG/INAACQG/INAACQG/INAACQG/INAACQG/INAACQG/INAACQG/INAACQG/INAACQG/INAACQG/INAACQG/INAACQG/INAACQG/INAACQG/INAACQG/INAACQG/INAACQG/INAACQG/INAACQG/INAACQG/INAACQG/INAACQG/INAACQG/INAACQG/INAACQG/INAACQG/INAACQG/INAACQG/INAACQG/INAACQG/INAACQG/INAACQm5x8o1AoFArFs+0KgPzwNxQAikSh1+v57ybwX6HX6591FwDgP4DnUwAAQG4U0v8OSkM4/K8h8O/E31AAKBLGbwAAgNyQbwAAgNyQbwAAgNyQbwAAgNyQbwAAgNyQbwAAgNyQbwAAgNyQbwAAgNyQbwAAgNyQbwAAgNyQbwAAgNyQbwAAgNyQbwAAgNyQbwAAgNyQbwAAgNyQbwAAgNyQbwAAgNyQbwAAgNyQbwAAgNyQbwAAgNyQbwAAgNyQbwAAgNyQbwAAgNyQbwAAgNyQbwAAgNyQbwAAgNyQbwAAgNyQbwAAgNyQbwAAgNyQbwAAgNyQbwAAgNyon3UHAAD4J6Snp6elpSUlJR0+fPjYsWNKpTIyMjIlJSUlJSUxMdHe3t7Z2blChQpubm6lSpVq3rx5jRo1PD09rduHQ4cONWnSxLptwiSFXq8XQigUCiGEdAzg34a/oYBlMjIybt68eebMmY0bN969ezc9PT07O9vBwSEwMLB58+bZ2dmlSpVycHDQarUKhSI+Pj4rKys6Ovrs2bORkZFqtdrd3b1bt27ly5d/8cUXi9mTLdBOfesAACAASURBVFu2bN269fLly3v37rXGN0MhyDfAfwB/Q4Ei2bFjx7Jly5RK5cOHD6Ojo+vVq1elSpXg4GCdTtehQwfz21m0aNGpU6fOnDnj6enZt2/fESNGWNCZkydPzpw58+zZs02aNOncuXP37t0taARFRb4B/gP4GwqYKTk5eevWrevWrTt37lxAQMCoUaN69uxZ/GZnzZq1ZcuWOnXq9OjRo02bNrk+HTly5L59+9q0abN48WIhxJ9//qlWq1u2bCmEWLNmzcqVK7Va7ZtvvtmtW7fi9wRmIt8A/wH8DQXMtHTp0rlz544bN27r1q0NGjT47LPPrNXyhQsXpk+ffunSpffee69Pnz6G8h49enh6erZr127GjBkTJkz49ddfb968qdPpxo4dGxMTs3nz5ubNm8+cOdPFxcVaPYFZ+C8m8B+iB2Cefv36NWrUyOrN/v333/Xq1fv888/1ev2VK1fq1Knz/vvvSx+tWLEiKCjo+++/l063bNmyY8eOglvbvHlz5cqV69ev/+WXX1q9q8853p8CAMiQv7//+fPnrd5s48aNX3vttSVLlgQEBPTr1+/UqVOGj4YPHz58+HDDaefOnQttLSUlxd7efubMmYsWLbKxsRk5cqTVO/zcUgsh9Ho9o9/Avxl/Q/GvFXP/ftz9u+lJCZrMDKVKbefs4u7t5x9QTqVSPduOBQUFhYWFbd++vWPHjtZtedSoURs2bNi0aVO/fv2K2ZSdnZ1Go0lNTZ0xY8Zrr71Wu3btxo0bW6WTyBm/4b+bwL8Zf0PxzN28duXmL1/63D+b9yOlEE5Gp6lCXH6yQqaNfUqLoc26FzcNFIler9dqtWfOnLF6vhFCNGnSZMuWLcVvx87OztbWNj09vXbt2pMmTVq0aFGVKlU8PDyK3zJ4PgUAyNe9qLuRX05yS4kWQvhY2ohddobdrm8u7PpGr1A8CB3RotdAK/YwPw4ODjqd7in9v4FSqUxPTy9+OyqVSqPRJCcnCyE6deq0ePHio0ePFn+tHQj2ZwAA5LV/w5oLY0MvjA1NnDlQCjdWodDrS/21XGr5yNu9MzIyrNVyXp07d7axsYmKiiq4WlhY2PHjx4vauF6vd3BwsLRrj3Xo0MHOzk6r1QohHBwc2rdv/8MPPxS/WQjGbwAAxs6GH1V9/07Jp38j17QHNyZ1SHLxCf7sZ2mGmdV5eHjEx8dLx7HR0TF3b6lsbMpXrmYcTaZPn+7l5dWrVy9XV1dzZgRLLl++7O3tbZVO+vj43Lp1Szp+7733WrZs+fvvv7NSTvGRbwAAQgih1+tPTuxin5XyT960RHL0xXEt79fr1nrEBKs3XqFChcTExAtjQ6VTacLzTSGEEFqlWvvyx3WDm/r6+p48efLcuXPly5d33jDTy9Gm4Daj/evpGnSKiorq37+/cbnhLua4Xy6o9aRZ0rG7u/uFCxcMH5UvX/748eOV/vzCuH71xXtztVCk2wkh7N74JrBy1d0rF/me2GAojG7Qq9XQcfEPH0Z/1Kvg2xlcu3Qha/Fow6leoazx5Z6i9icmuH/LgU/9TTGeTwHA806r1Z4f1+riuJb/cLgx8D35+4WxoYemWG1eTmpq6oWxodWrV79//77JCiqdxnb11AtjQ5VKpUKh0Ol0UVFRN8sEFdqyz92T548eSkpK8vf3t0pXK1eubDyVx7ukZ97X2g98MNQq9zLJw9MzyfmJsag9sybmV9k43AghKs8Pe1rdKjbyDQA81+7evnV5fGuFXvesOyLck+5eGBuanZ1dzHZSUlJuvdNJCOHm5paYmHjSq0EBlZs3b65QKAYPHmxra6soX9uc9i/cvteiRYuyYV8UXtUMycnJOt3jH35pTfz169dz1fFMiLTKvfITOGGR8anPnQiT1XL90egVShubQoa7niGeTwHA8+vM+DZqreZZ9+IJVye0TbUv0XDu75Zdfu/u3cTPc8aBKlasKIQo37KrwnVAtTr1DHVOHz1ks2qKdJwcfdfR0bFChQpTp05N+v0r4ZxTJ8PW+YX5W3M1fu6N1g87vRUx5aNXgiurhGb/+tXN83kXrIBHPEKI6kbHvr6+9vb20vGuZfNaZV3/zlRoOD6pa8O5mwto3/gJUdaAaXUbNyugA7l4eXvfdPR0SXtoKNn76/ehfYfmqnZ+Umdbo9MCBm/M//pPD+M3APCcOjO+3b8t3EicMpIi3upi2bUJswYbjiN/+MzGxubshYvG4UYIUSeoSfXFe9NtXeI8A9/59LOTJ08OGDCgR48ejZwLGTq63GL0m+9OHT9+fHNxTwihOvGHyWrH0hyaNGli5ptQkZGRhknQfqe3CCGkuPPQrWyGjaOhmlPGI3Nas1iZ8QuNT0sdMNF5W22m4fhfPngjyDcA8Hw6Nqm7Wpv1rHuRr/rzLVk9T6fTGT9oa+SUZW9vf/Pmzfxu0eKTFeY3HhkZuXjx4ho1avjs+UYqcUp9aLJmdXVyQkLCxYsXzWm2fPny0iI94ft2SyVqtfpkgqbO24tdXptjXHPXF1PM721R+ZV+YjqRQq83fmomhDjw+y/Gp6k93316nbEKnk8BwHPnwthQ58JrPRvJjiWDZq+z7Nq/ls/3NTpNcPXz9k621i5U69atS0lJaeWaUVqZM26R6FEuv8o2NjbOzs4m3yq6V6l5m/GfGk41mpwhNMffpkkHAQEBiTaJrq6urq41TqntbDU5oyZ+1w9lZWXZ2tqKp8Nl0nfJc4cZTiPe7m78RMzzz68Nx3qFslHLdgU0VcDrVHHNh7XoO6RYHTUP+QYAni9/v9vPzRrtpOuU6+46/xXnmJ1niWAHpb69T1p33xSVomjLB+sUKovDjRBCFXPN+DSjYlD2iT8iIyMtbtDg66+//vnnnye/Mab28R8NhZc9ajTVaNTqvL9JFQqFIjY21szGk5OT/1r9jeEVJi8vL5/GOevf2Az5TKx4/DbT4RmvF2nMqUjKlCt/wejU+InY9SuXjGumdn/7KfXBisg3APAcOfRef/firUe85o7rHzGOBddJ1yk23XPadM9JCOGg1M+u9cDNRltoy/fLNmz99pxCqxVAa+fyxHncHVdXV4VCce3aNWmusfnss1IMgxB/2VVa/fe5yZMn1z74jaFCuq3LqrW/LF353YkTJ/JebmNjExsbK8xYJ9HFxUWlUnkfWWsoUSqVjo45P+Ea9eqfUakN06RKPbweFxtbysurSN/FfPbjl2YsfLwyze7Zk6U/kcxFowyFeoWyUesOT6kDVkS+AYDnRWx0tHuy6fVgzHE/Q/32uSKvbJyuU4w7XcrNRreoTmwBqxQnO3oWM9wIIeyqBYnbjzdb8L0THhDQ8MyZM8Vp82/n6j/tP9WnTx/jcCOEqD9/S92xY3fu3Hn69Ok6deoYf+Rsq/Lw8Lh9+3b8yyYWLfTyeWKmS1ZWlkajiazXs9zJnJX3oqKilMrHs2N1/T8Wq6caTm/Ofq3U3E3F+UYFqFCpivEQju/t4yLPa+Ep3SYV2k58uzH5feRfpabF3SsS8g0APC9iZwyw+KWS72+V2B1n+Y5LidnKweE+r5R71KJkWt5PdQpV0Oz1FjduENKp56WwxcYlzs7Oxdll83KD/ovmL8nKynK8sE/kvMQtHroHNJv2gxCiX79+u3btunjxYq58k5KlTUlJycrKSrMv0a5dQfNUhBB2dnZCiPS0xz+WmJiYe8s/uLBlpnSaa7qNc0aiZd/FTPeqt/O7sPNxZ+7fP/fr18azmoLaFL4fe9OufZ5C14qG96cA4Lmwa8l0pb7wh0R5peuUg8J9ihNuDJZHug4K97mUYmdceDLRfsjxUl26j8rvKvMplcpo/ydeBff19TVZc9+6VdI2n/lFnwxbp+geHyz6Ye2gQYOEENpaoYaPPBNytotq3Lixn59f3udTzraq8uXLp6WlpaQUvh508vmjer3eMMtYCJGVlVXw5p1nxrcptFmLtRn9vvHpg89e9r2633D6qOvkp3dr6yLfAMBzwe/iLguuWh/l8toJK8/2mHHJ/eDDnN/f8Vmq+dfchBD3ohND21jhtZpW7z6xrHCtWrVUKtW1aUN2LZ52LuLYmWOHdy344MLY0FJ7c2bpXhzX0mQ7Lq8vGDN27Ny5cydPnmxra/v7tieWutn11UwhhEql6tix48GDB/Ne7urqqtFozNk31NfV0cbGJjomxlCSnp5e27WgC9VaTfFXeS7AvcqPfyaKJ/NfcLtOT+++1sXzKQCQvzPHDhfpP/dnH9kvvFoiU1/4r+cypT2mvDuiYcP6xoUPHz6cv2DFjj9NTLyVLL1Zwkmlr10ic/yZUobC5JTM4KYDjhz8qSg9NcH17R8ezc6JSo6OjtnZ2e6vzHD99RNxabdSCL889U9O6FDvix3GJbur9Frao4dWq61fv74QQq/X37t3L7xZxwYxx6QKfhfCMjIm2NvbBwUFLV++PG8f1Gq1Xq+PjIzM701paYXfXYs/1eq0CoUiNT1DCBET3P/gzdiUlDXVFx/PVX/vp6O8Yh+/xHTos7GhHy0168dRdK3HfXhx3F95y2O9qpq59HCh220WvMCxVTB+AwDyp/7xvULrnEi0Hx7hMyjcZ1C4z5GHdt++EOOkyndTKm+vEhFH1kYcWbtp/Ve5wo0QwtPTc8a0t6UKtjYqky3Mv+Y2NMI7V2G2Rls/uN/0GQtNXmIm/7IB1RfvjS7zghBCq9UqFApb5xIma2pU6kpf/GkcbuLTs6fH+61Zs2b21LdVqpye29nZZWVlJbiWNr72xqQOGo2mWbNmJpfxLVu2rFKpPH36dAH9zMzM9Lu0p37SBY1G41CuuhCi5cCR165dCw4Ozls59MMnZjd7xV2Of2h6dcHiUygU9yqEFNqHfznyDQDIXK6FaHNJzFZNOV9yULjPF9fcStpqvqgdt6pB9Kvlkx5pVKla078jhg1qu32zuYMHhw/8VLdWuSJ1eOOWw6+PmVp4vQK1emd+udnbdTqdSqXKyMjI9alWqVaN+rL2wl3G6WSfb/OPbzkEBASsqG/nc+xXw9ydrKwsFxeXrVu36hRPZLULEzsKIRwdHfMuIXj58mWdTpecnFxAD49Nz3kT297eXq/XxwT3P3fu3NmzZ1u3bm2y/gPPQOPTq7NeK6DxYmr15vRcJbGlqjy92z0NCotnlQMA/hN2zZ/id+OQcUl8lmr2FfeoDLUQwt9B807lhLzr0wwK9zHZWoTRSi3mS05ODm37alGvWr92VrlyARbczmDPnj0jR46cNm1av3798qtz+PDhH3/8MSIi4qOPPmrSpImbW87yhz179tywYYMQok6dOrNnz3733XdfffXV0aNH57q8RYsWJUuWXL/+ife/hg0bdvjwYZVKNWvWrM6dOxfcyeHDhzs5OX3++edt27bt16/fG2+8YclXxZMYvwEAmTOEG70QyyNLDAr3GX+mVGym+s3ApFUNomfWMLH4XkK26YdKG36ZZVkfXFxcJo0v8jvDvfq9c+xYuGV3lHh4eCgUigLm+S5evPj9999XKBS///57p06dDOFGCOHp6Xn48GEhhF6vv3HjRt26dX/++ee8LXh5eV27du3SpSdW+NXr9b169XJwcMg1ePbnn3/26tUrODi4atWqTZo0adu27aZNm7p163b9+vWtW7dmZ2ePGmWF98ggmF8MAM+D/Q8cl0e6SsP1Hb3T+pcpZDPqH2+55i308XILCLB8NKV//17zFq7Ti6I9NHj9jbkfvDeoezcLX9tRKpV6vd7kc6K//vpr0aJF0dHRb731Vp8+JrJXqVKl9u3b17hxY+kJ16BBgyZOnBgXF1eqVCnjatI0nVwvNN25c6dp06YZGRmGWy9YsOC3337Lyspq2LDhiBEjvLy89Hr93r1758+fHxMT4+PjM2/evNmzZz+97aWeN+QbAJCnH1f9snDJRiGEED7dfFN/bFCEbRnCE+3yFm7bXNzppcf+/qlhyMtFvWrazFXTZq46dugnw4Rfczx8+FAIkZqaqlQq8+abvn373rx5s3fv3u+8805+Lfj6+v7xxx/vvvuui4uLm5ubnZ2dQqHYsGHDyJEjjaupVCqdTnfnzp1atWpJJY8ePYqPj3dzc5Nu/fXXX3/33XdeXl6jRo2SVtMxaNiw4eTJk5cvXz5nzpyAgICWLU2/rA4LkG8AQFYuXbo87s3Z8Ymp0qmzSv91vZiCLzGHh7tT8Rsx3nagqBo1GXBgz0rDxkwm7fxzd2k/n59//vn06dMPHz5MTEzU6XQKhWLdunVXr15t0qRJcHDw1atXFy1aFBgYuHTp0tTU1F9+2Wjcwksv9ZAOYmJiSpRwS09P37YtrGTJkjExMV5efqVKldqzZ4+/fznjS1xdS2RnZ69Zs6Zjx45CiAcPHvz11wFnZ2e1Wl21atWlS5d6enoOGTKkXLmKSqXy9OmztWrVyPVzsLOz0+v19+/fP3v27NmzZ+Pi4ipWrPrHH1saNGhQqpRv27Ytf/7557S0tFGjRuV90BYdHR0R8cRbWp06tS/aT1amyDcA8J93/vyF8W/NS0hKzftRgGORF4Iz+QBp6nvDit4vE7p2arR52zHLrm3WariPl1t+w0gZGRlff7VYGkepEFiteg0Hb28fby/3Tz/9qHnz5hUrVly+fPn8+fOzsrJeeumlqVOnCiHavPh6rkYM+ebixSsLv9pmq8j4cNp3wfV909LSPpz23eQ3h3322WcffLJYoXyc9nxLaezs7G7dylnU+MrV6zNmr/ZwsXF1db1y5Yqbm1tQcKuVqw4IcSDXvUq4Ouzcvmz9+vWLFi1Sq9UZGRmzZ8++du1aSkqKrVMNfdaVI0eO6FSBfn5eM2bMsLW1LV26dNeuXXM10qn7m7lLyDdCCPINAPx3ZWZmTpw84/CxKwXUsVcV+SXZTJ2JUZYa1asWtR2TqlUpb3G+EUJExyY2bzVk/54fcpdHR48YMSIoKOj2fbszF9OFuC2EEOKyXpeu1+vDw8NPnDhRvXr1oKCgqKion376KTw8vEqVmlpNlkpd0HyXtLQ0YZOekJCQlZUlhLh05XZWVtaiRRMnvvs4Y92/f2/p0qW5XnpKTk6eNGlSSkpK7dq1d+wyvcFn0qP0RiE9S7lnDhgwQKfTLV++/OLFi8nJyTqdrlPnGuvXRahUqvfe77Zv3z5nZ+esrKy4uLhcLWzdGpa32fPnL9SoYeY6fHLG+1MA8J+0fv3mZi2HFhxuLKMy9bKRtea92toVt53UtMy1Tz5UEkIsXrz4wYMHyamPJ+goRcrg/o1rV3cXQnh7e48ePXrJkiWDBw9+7733zp07J4TYtm1TtUp2Nat6FnCvrKwsoRdeXl537twRQmzactTNzW3Lli3GdTw8PMe8uSA9PT0sLCdtbPptXmZm5htvvBEaGhobG1tA+4EBduXLl3d2dr1y5YpWq01KSlKpVDY2NkJoKlas6OPjs23rptWrV3fr1i00NHTPnj25Lv9o+nd523z19c8KuOPzg/EbAPhP6tWra69eOU8r9uzZN+XDb7M0JrbPjM/nTe8C2ChMrAd49Gh427atitpUXseO514Kr0i8Srn+seXbXIWnTp06cOCAh4dHaV+nZsE+J0+eTE9Pd3V1VavVWRo7nU5XtmzZbt26GV/iUiKwbDlnT0+3I0eOVKta9U5UWkq66eCl0+li4lI1Go208M/rr79+4MCBiGOPh6AGDBjw1oSBEyZMMKwiOO7Nj+3s7L5Z9nufnk1jY2PzrhjUvtOrMTEP69Z0jY6OvhaZefzUzvq1XfV6vUKhGDRo0N27d3fv2u7k5FQhsNbfh/7U6XTVq1fv06fP/v37jRuZ94Xp53SZWZqwsN3t25teJPD5wfgNAPzntWrV4vDBnyKOrH25b2iuj2IzrPPf+d+37LVKO3v2FrRlQcHq1grIG26EEHXr1u3SpYunp+eVK1cqVaqksvEq5VMtIaXkylUHLl2JNvnW1YXLUTEPNIfDH7h7Vnz06FFyUmTQCx4aTe5ljh0dHWd88qqN2ubBgwdSSfPmzbVarfEQjlqtfvHFF3U6XVpamlTy9sQRaWlpGZk6pVKZmJiY9+5h25YNHxx6/fr1Eu4BSpWjEMLb21taarlhw4bXbyYkJyd7e3ufOH27UqVKer1eWkm5efPmxo2s+WWv4bhMaY/OLzY0nE75yMSWWM8b8g0AyMfEt0ZJuz5FHFk7dGBbIUSqVjk43GdPXEGvHeVlr8w9a8cqD8IyMzOzTQ0yFUohFBFH1q5Ylu/qgpMmTVq9erWTS+mVqw4kpaiiYzOlq4QQOp3u9u3bR4483rEyuOkAw3H37u2jYh2dSwScPXtWn3Xjww8/NG5Wo9Hcu3fPx9dHrVZv3rxZCFGpUqW0tLTMzExDHWnlG4VCceVKzo/o0aNH9vb2Qiji4uIMocfYihUrVqxY8c4771y7mSSEUIj0u3fvKhQKpVJpb2//KFlpY2OTlJSkVNnfibabNm1apUqVcrUw8vUpxqeb1n/1yUcTDad6oV+xsrjblP7XkW8AQJ7GjR0RcWTt/t0rqjhnf3fLdVC4z7jTXnfSTWwGmVd3PxOvYi35amUxuzR42NsWXOVgbxN+xMTCwYX6Yu44IYT0TvXYN+dLhYmJicYZq02rJkKI1HS7tOzSNo7VS5Qo0bBhw6CgoBs3rup0Gnd397i4uN17LyiVyo2bdtYP7jdy7FwfH59jx47VD+4n/SNNPW7ZsqU0R0cIERMTY2trq1Lbm9z5a9GiRWvWrJk6der6jfuFEO1bVXBxeOTl5eXs7Lxt27amTZsKIWydasQluikUCpVK3aFDB2/v3BuRhp+8bjj29/PI+S4taxsKv/p2i3i+kW8AQM6cnJymVH24qkH01KoJWTrF++c9B4X7LLjmrtHnu2WBEKKTT0rewpU/7ixOT9LS0q7dKPJKPKV93Q/uXWXZHZs1DRFCSNss6oU+KipKCNH7pcfjHP36tMh1ycSJE48fPz5q1KgVK1Zkp10qUaLEvn37hBBOTk6PHuUs+uzt7W0YqhFCJCQkCCEUCoWhwvnz552dnYUQNWvWTE9PN25/w4YNX331Ve/evfv06VPS09avVGpUVJRQeXt7e9vZmVhT0aRvlz3xA1nx7afSwcwZ7xqXX7p02cwGZYl8AwAyF9t0sBCiinPm0noxqxpEr2oQ3cU3ddwpr0HhPoPCfeZe9cg2lXUauWfmLawf3C/XRgRmunkzslmr4UW96siBVZs3fm3B7Qy+mPOWYf+prr0m7tixy3iVoMkTXzfeP9xg2LBhn346vWevPrdu3Xr06FG5Mo716tXr3ClnceG6desaVrsR/1+00N7e/vr1nDEVnU4nhRVHR0etVnv8+ONHY1999VXVqlUDAwPffPPNfXt3unn4n7uc+ShFBAYGFrzZuLGlK7YZjkv7upcsWdLQkyaNH7/GP2DoR2Y2KEvkGwCQuSa9BuUqCXTK+rpezKoG0S/7J59Osh0e4T0o3GfzfWfjOuMCE0y2FtxskEajKVIH7t+/37v/u4XXM6JUKCKOrDUZPorEw8NDr9cbhkamfPx44u30j0aI/z+9ykulUm8LuxgaGpqQkHDv7sWdO3deunTps0+GHTmwysnJKTMzc8bHQ48cWHXkwKr4+HghhKOjY1ZWlhRlMjMzq1atKoRIT0/X6XTGQzhJSUkPHjyYP3++v7+/VlnhwuWcH7LUQ2moqWCT3p5ufDrrs/FxRt57+4m9I3bv3ltog3LF++EAIHM2NjY6hVKpNzEX5EWf1Bd9csYzdsU6DQ73kX7B9vBL7emX/GWduHGnS+W9KqjpQFu16q9dK+zt7Qu9e/3gfkXt8OrvPq5WzTrLCdaqVUuhUKjVuX/ZOTrYvvhi20Ivt7GxsbW1zdB4dezYLCwsbPfu3dWrVy9ZsqRGo8nOzpbil7TdZmho6L59+yIjI0v7l01NTfXz8xPirpRXjOPg1KlTlUplly5dJr8zw/hGy1f+ptPpDG+Y5yc1NfWv/eeMSwYO+7iA+m9P+SaidWihX1OWGL8BAPlLbDe60DptvFJ/bBD9ff2YYPeMjfecBoX7TDpbspSt6dedsjTaJqFDu3QflXdRXYPpny0sINyohahbIitv+a4/vrZWuBFC3L59W6/XGz9Okqz+fpo5l/fq1UupVNrZKt3c3Nq0afPpp582aNDgzJkzCoXi66+//vbbb1esWJGSkiKEaNu2bWZmpvS21PXr16tXry6E2PbHPumtKEOD3bp169KlyxcLvt2z76zxjSpXKqtWqwsdvxkwpMgTtH/4MffqO88Jxm8AQP6adul9IWyxOTVVCv2YwMQxQkRnqmdfdo/LKmh5wHvRiR26jBNCqFXK6lX9S5YskZ6eefHy3cQkEy9FG3NR676qGyuEmHbR80rq44dQRw+uzjvWUhxly5Y1ualnQECAOZc7OTllZ2dnZ2clJSXFx8dXrFipYsVK5cuXf/vtt1u3bh0ZGXn16tW4uLiWLVu6urqmpaVdvnxZrxdpaWnSSIxWm7MEzr79B4UQWo327yOntm7bl619Yi1BlVLRo3vH3zf9Kk1VLsCduw/N/eb/t+irTUMGF3kITQbINwDwXEjsON5t+0Lz6/vYaebXzhmbiUhwWHC9RAGVNVrdmfO3zWnWRqFfUT/GMOflg2oPE7NV406Xmj1jVOun+SSlTs2A0+dyRnGOHDD3haxBwz9Wq9U9u4dWqVz+yy+/7D/4AyGEVpMuTZcJ23NDCJWtrW38I6cJE0ZMmTIlIiIiPDw8JSVlzpw5WVlZ16/aa7XaFStWpKam1q5dOykp6dGjR6V9FJFRj2/x6rAXR40cEhERoVQqU1NNvJZvENJ8oPHp+rWzypUzndKatRyclv54bGz6Zwunvj/ezK8sGzyfAoDnQkjHHhZfW989fU6tB8XvQzff1JVG4UbiZqNd3EL39MKN9Gr3yuWzDCsfGk9bgIcWfAAADFRJREFUtitwPyylUq1UKn19PB89eqTV5jyqU6kdPD09DWvbZGdnq22cPUt6ubu7N2nS5OUBA52dnRU2/mr7QG/fKiqVqlGjRoMGDSpTpoyLi0uvXr0Uqpwdr5QKxc5tS0aNHCKE0Ov1Wq3WeNnAXLKzszOznpjWnV+4EUJ8+cUk49ONmw8X8B3linwDAM+L+PZjLL7Wx06zqkG0p40lqw8LIUrba35sEN27tOlXoEukxh6YOtjivhWsVq1auRahMZ80N3nPnj329vZOTk6GcgcHh0OHDgkhZnzyiuENLB8fn/379/t4e2VmZmp1SrWNo1Co1Gq1RisWLw1b89vxQ8di5y3afPP2o5CgKrv++Pr44Z89PXOyjrT5VH4vcwkhhr/yxAtoA/q1LKDbdevWzlWyb9/BonxvOeD5FAA8L5p26bP7coRv5BGLW1hQJ04IkZit+vSiR8FTcyRuNrov6xS0gbaBZ+LtC2NDK8zdYc47WfmZM2tK3sKCn/v4+fnl3f9SCBEa2iziSDMhxAcffHD8+PEzZ86kpaVFHMnZIbx79+7JyckRRzatXr26RIkSR46sFUKcOd1y7dq1W7ZsKVeu3LZtvwshwsLC3n333J3bN03ewphKpVIqldKbVn8fWJ23wqof5hXcQi6F3lH2GL8BgOdI60mfF78RNxvt/NpxqxpEz631oLVXmpuN7slPdR280r6oFbeqQbSZ4cbgxqQORV1cp1B+fn5qtXrv3r2WXV69evXIyMhbt275+/sbCqtWrSo9S8rKypLeDxdCODo6RkdH7969u1atWlJJ+/btnZycTG6xmZdOp5NWWIZVMH4DAM+X6ov3nh/bUiEKX0quUN52mqFlHw0t+6j4TRlcebPN/bpdWr8ysfCq5vH29lYoFCa3gjJH//79582bd+LEia5duxoKK1SosH379n379u3Zs8ewoPOQIUOUSuXp06c///xxiPTx8bly5cqDBw8MqwybJC1CaHKrc1iG8RsAeO5UXbjrWXehIL6ntvz18/LC65knMDBQq9UaZgdbICQkRKfTGW9yKS2LHBERkZycbLxozaBBg+bOnWt8bdmyZc0ZkZLWRLa4h8iLfAMAzx2VSuX+3k/PuhcFsXMzsW6yZfz9/bVabXEee1WpUqVevXply5Y1lPTu3Ts4OHjjxo2RkZFdunQp4NoWLVrY2NgYb0FlUlpaWsHzi1FUPJ8CgOeRb+nSvov3nnqzg62mkD0B/mEp9m6N5m6y+PKaNWt26tRpy5YtFy5cEEJUqVJl3bp1arXaxsamatWqly5dkqp9++23x48fX7ZsmXTaunXr4ODgu3fvBgUFjR49esqUKRs2bOjZs2ejRo26des2ZsyYMWPGTJgwoW/fvlKbly5d6tat29GjR+3s7Jo1azZ37tzLly8nJye3aNHi9ddfHz9+/MKFC4UQ9evXDwoKcnNzu3jx4osvviiEGDJkiGEez4wZM/L2Xwjx4MGDmTNnSvOsZ8yYodVqJ06cuGDBgtOnT6enpwcHBw8bNszPz0+j0ezevTs8PFwIsX///ubNm0uXN2vWrFmzZpcvX+7UqdPw4cOFEA0aNGjfvn18fLydnd2CBQuEED179qxWrZoQYujQoZUqVTLcukePHuXLl09ISPD39582bZoQonPnzlu3bpU+PXDggL+///Lly7dt29apU6eaNWv2798/1w981qxZ77zzzp9//ilNeNq9e/fSpUvr1KkjhOjVq5e0Ldfw4cMDAwMt/iM2E/kGAJ5fdRfsODa5h3N6Icvm/mPuVQhp89ZnFl+ekJDw+eefd+7cedasWVLJyJEjT506pVQqExIS3nvvPUPNjRs3VqlSxXBaq1YtKW307dt39OjRM2bM2Lx5c375IyAgoFatWufOnevcufOpU6fq1Knz0ksvGZKTsZIlS3711VdCCL1eP2bMmCVLloj8Y41erzc86nrnnXe8vLykY5VK1aZNm+vXr0+fPv23336TCqVGEhISYmJijB+c6fX6AwcOSMdhYWFxcXGlSpUqWbKkVP/TTz+VPmrTps3o0bm37JgyZcq6deukOUA3b948ePBg06ZNc9UpX778jBkz9u/fLzUYHx8/e/bsjh07Gn7gBlKFGTNmjB07dvHixUKIdu3ajRw5UvxTeD4FAM+1RnM2Vlm4W694xr8O7gU2rb54b3HCjRDC3d29c+fOcXFx9erVk0psbGycnJxsbGwiIyMNi80MGTJkzZo1H330UaNGjaSSY8eODR06tE2bNoMHm7UMz7lz5wy3EEJI4WbZsmV5f81LFArF/v37pePMzMzMzMy8z8tUKpUh32RlZUnVpNP27dt//PHH0mCMZOjQoQMHDuzXr59xuBFC3Lhxw3Dcvn373bt3CyGio6OHDh3atWvXEiVyFqHWaDTG7UvCwsIME5zLly+/fft28eSW5nl3uvDw8OjYsaPxDzyvV155RdqWy+RNnx7yDQA871QqVY0v98T41npWHfD+eF2bCdOL386vv/6q0WhKlSolPUiSdOrUyc3N7cyZM4YSPz8/W1tbW1vbsWPHSvOOGzVq9P3338+aNatu3bpm3uvkyZPNmjWTjn/44QchxKuvvrpv3z6Tlb/55hvD0IudnV1iYmKubbak9f0Mp7a2tnZ2dtIuEEKIBg0arFq1av369YZZ0t9///3q1avDwsJy3SgwMPCXX36Rjhs3btyvXz8hhI+Pz/fff79ixYoXXnhB+kitVhu3L9m4ceP06Tl/Ct27d5cGYAwvt3/wwQeNGzfOdbu1a9dKP/DevXub/OI6nW7o0KGOjo753fTp4fkUAEAIIVpO+fLe3TuJnw/6J28aEzKg5cuvWqu1vn37btq06dChQ6NGjfpfe/cXkuoZxwH8OaaohzJhaFYWhF15XCAJtqxNtkjLWSwS5NjyIiIYJ6iLyC5SIjgF0d1gXXQzootg4dlFIwgPmORhGBlUtHejPxC5o1KdjBGmxC6ec+TM2sq0Gvr9XL287+vz/vTqy+P7PD96RqFQcLlcmUy2t7dHe2p6PJ6xsTF6tbOzc3Z21mKx1NbWEkKqq6tHR0eHh4cJISaTKWlweg8hxGAw0IOZmRk64dHe3m6320UiEZ3z0Gg09IaamhqHw8Hj8fr6+vh8/sHBQVVVldlsjsViCoViZGQkMfjm5mY8Hqd9znk83sTEBD1vs9ncbrff7yeETE9P0/K0Wm1SbS6Xy+VylZSU9PT0NDY2Dg0NSaXSN2/et2Vobm4mhIhEorm5OZrJgsGgw+EghOh0usT3KisrGxgYsNvt+fn5r169fwVqZWVlampqd3d3cHAwMX/T2tpKD8xms9Pp9Hq9iR+cBkSpVErHV6lU6+vr9FIgEKAn9Xr91aiUcU9u7MYOAAC55vWP30t8P93f+H/KNF/1X/8ayn2w2WxOp5NhmAd7YkIoFNre3vb5fB6P5/DwUC6XV1RUfJxsqLW1NavVajQaX75M6x86SMD8DQAAJPvS+oJYX3h/cabUcvw2wtquL9q/lWd20JtwOBwWi7W4uKjX6x/miUtLSwzD+P3+jY2NvLy8yspKo9FYVFT0b4vJhULh5eXl6enpw5SXC5BvAADgerXN35APXcc3Vn999/MPn5zspzrIuwIJ/+vvlJrPM1xcKmQyGZfLzXjnh6sWFhai0ejk5GQ0GlUoFHV1dQaDoa2t7cYPstlsNpsdiWRyJ+gch3wDAAA3+1SlJio1PQ69ffub93XsjzVB+Pen0bMn/3zP4S+eIFL87Omzz5TaxnSaZWYQ3W3l5ORelsEfHR11dXUFAoFYLKbT6cbHx28TaJKUl5cLBIL9/f17KDBHId8AAEBqxBKJuO05Ic8fu5Dbqq+vj8fjoVBqzT7/287OzvHxscViYbFY3d3dLS0tH2+UdwdCoTCzFeY45BsAAMh+fD7/7OwszUEuLi62trYYhpmfnw8Gg8XFxQ0NDf39/WkmG6q0tJRhmGt31YM7QL4BAIDsx+Fw6OrrVK2urp6fn8fjcZ/Pt7y8HA6HCwsLtVqtUqmkLRcypampye12J7qRQ5qQbwAAIPt1dHQk9i9Oic1mi0QiYrFYLpfr9Xqr1VpQUJDx8siH/gxJ+/7BnWH/GwAAgMcXiUTUanVvb+/VzlBwB+jPAAAA8L9gMpkkEsljV5ElMH8DAAAA2QbzNwAAAJBtkG8AAAAg2yDfAAAAQLZBvgEAAIBs8zeWOEmvGESoLgAAAABJRU5ErkJggg=="
                id="p1img1">
        </DIV>
        <?php 
 function penyebut($nilai) {
     $nilai = abs($nilai);
     $huruf = array("", "Satu", "Dua", "Tiga", "Empat", "Lima", "Enam", "Tujuh", "Delapan", "Sembilan", "Sepuluh", "Sebelas");
     $temp = "";
     if ($nilai < 12) {
         $temp = " ". $huruf[$nilai];
     } else if ($nilai <20) {
         $temp = penyebut($nilai - 10). " Belas";
     } else if ($nilai < 100) {
         $temp = penyebut($nilai/10)." Puluh". penyebut($nilai % 10);
     } else if ($nilai < 200) {
         $temp = " Seratus" . penyebut($nilai - 100);
     } else if ($nilai < 1000) {
         $temp = penyebut($nilai/100) . " Ratus" . penyebut($nilai % 100);
     } else if ($nilai < 2000) {
         $temp = " Seribu" . penyebut($nilai - 1000);
     } else if ($nilai < 1000000) {
         $temp = penyebut($nilai/1000) . " Ribu" . penyebut($nilai % 1000);
     } else if ($nilai < 1000000000) {
         $temp = penyebut($nilai/1000000) . " Juta" . penyebut($nilai % 1000000);
     } else if ($nilai < 1000000000000) {
         $temp = penyebut($nilai/1000000000) . " Milyar" . penyebut(fmod($nilai,1000000000));
     } else if ($nilai < 1000000000000000) {
         $temp = penyebut($nilai/1000000000000) . " Trilyun" . penyebut(fmod($nilai,1000000000000));
     }     
     return $temp;
 }

 function terbilang($nilai) {
     if($nilai<0) {
         $hasil = "Minus ". trim(penyebut($nilai));
     } else {
         $hasil = trim(penyebut($nilai));
     }     		
     return $hasil;
 }
 $angka = $datamaster->nominal;
 ?>
        <DIV class="dclr"></DIV>
        <DIV id="id1_1">
            <?php if($datamaster->tempat_pembayaran == 'tubanan'){ ?>
                <P class="p01 ft0"> Jl. Tubanan Baru 10/Blok <NOBR>K-15</NOBR> Surabaya 60188, East Java - Indonesia.</P>
                <P class="p1 ft0">t. (031) 7328540, (031) 99020730| m. 085733301090 e. care@creativemedia.id | w.
                    www.creativemedia.id</P>
            <?php } else { ?>
                <P class="p0 ft0">Jl. Nginden Intan Timur 18/A3-10 Surabaya 60118, East Java - Indonesia.</P>
                <P class="p1 ft0">t. (031) 59173739, (031) 99020730| m. 085733301090 e. care@creativemedia.id | w.
                    www.creativemedia.id</P>
            <?php } ?>
            <TABLE cellpadding=0 cellspacing=0 class="t0">
                <TR>
                    <TD class="tr0 td0">
                        <P class="p2 ft1">&nbsp;</P>
                    </TD>
                    <TD class="tr0 td1">
                        <P class="p2 ft1">&nbsp;</P>
                    </TD>
                    <TD class="tr0 td2">
                        <P class="p2 ft1">&nbsp;</P>
                    </TD>
                </TR>
                <TR>
                    <TD class="tr1 td3">
                        <P class="p2 ft2">&nbsp;</P>
                    </TD>
                    <TD class="tr1 td4">
                        <P class="p2 ft2">&nbsp;</P>
                    </TD>
                    <TD class="tr1 td5">
                        <P class="p3 ft3">KWITANSI</P>
                    </TD>
                </TR>
                <TR>
                    <TD class="tr2 td3">
                        <P class="p2 ft2">&nbsp;</P>
                    </TD>
                    <TD class="tr2 td4">
                        <P class="p2 ft2">&nbsp;</P>
                    </TD>
                    <TD class="tr2 td5">
                        <P class="p2 ft2">&nbsp;</P>
                    </TD>
                </TR>
                <TR>
                    <TD class="tr3 td6">
                        <P class="p2 ft2">&nbsp;</P>
                    </TD>
                    <TD class="tr3 td7">
                        <P class="p2 ft2">&nbsp;</P>
                    </TD>
                    <TD class="tr3 td8">
                        <P class="p4 ft4">No : <?= $datamaster->kode_pembayaran;?></P>
                    </TD>
                </TR>
                <TR>
                    <TD class="tr4 td6">
                        <P class="p5 ft4">Sudah Terima dari</P>
                    </TD>
                    <TD colspan=2 class="tr4 td9">
                        <P class="p6 ft4">: <?= $datamaster->nama_siswa;?></P>
                    </TD>
                </TR>
                <TR>
                    <TD class="tr5 td10">
                        <P class="p5 ft5">Received From</P>
                    </TD>
                    <TD class="tr6 td7">
                        <P class="p2 ft2">&nbsp;</P>
                    </TD>
                    <TD class="tr7 td2">
                        <P class="p2 ft2">&nbsp;</P>
                    </TD>
                </TR>
                <TR>
                    <TD class="tr8 td6">
                        <P class="p5 ft4">Jumlah Uang</P>
                    </TD>
                    <TD colspan=2 class="tr8 td9">
                        <P class="p6 ft4">:
                            <?= terbilang($angka);?> Rupiah
                        </P>
                    </TD>
                </TR>
                <TR>
                    <TD class="tr5 td10">
                        <P class="p5 ft5">Amount Received</P>
                    </TD>
                    <TD class="tr6 td7">
                        <P class="p2 ft2">&nbsp;</P>
                    </TD>
                    <TD class="tr7 td2">
                        <P class="p2 ft2">&nbsp;</P>
                    </TD>
                </TR>
                <TR>
                    <TD class="tr7 td6">
                        <P class="p2 ft2">&nbsp;</P>
                    </TD>
                    <TD class="tr7 td7">
                        <P class="p2 ft2">&nbsp;</P>
                    </TD>
                    <TD class="tr3 td5">
                        <P class="p2 ft2">&nbsp;</P>
                    </TD>
                </TR>
                <TR>
                    <TD class="tr8 td6">
                        <P class="p5 ft6">Untuk Pembayaran</P>
                    </TD>
                    <TD colspan=2 class="tr8 td9">
                        <P class="p7 ft4"><SPAN class="ft7">: </SPAN> Pembayaran <?= $datamaster->kategori_pembayaran?>
                            Bidang
                            Studi
                            "<?= $datamaster->nama_bidang_studi;?>"</P>
                    </TD>
                </TR>
                <TR>
                    <TD class="tr6 td6">
                        <P class="p5 ft5">In Payment Of</P>
                    </TD>
                    <TD class="tr6 td7">
                        <P class="p2 ft2">&nbsp;</P>
                    </TD>
                    <TD class="tr7 td2">
                        <P class="p5 ft4"><?= $datamaster->nama_level_kelas;?>,
                            <!-- Inspirasi Class, -->
                            <?= $datamaster->nama_kategori_kelas;?> a.n <?= $datamaster->nama_siswa;?>
                        </P>
                    </TD>
                </TR>
                <TR>
                    <TD class="tr5 td6">
                        <P class="p2 ft2">&nbsp;</P>
                    </TD>
                    <TD class="tr5 td7">
                        <P class="p2 ft2">&nbsp;</P>
                    </TD>
                    <TD class="tr7 td5">
                        <P class="p2 ft2">&nbsp;</P>
                    </TD>
                </TR>
            </TABLE>
        </DIV>
        <DIV id="id1_2">
            <DIV id="id1_2_1">
                <P class="p8 ft8">Rp<SPAN style="padding-left:182px;"><?= nominal($datamaster->nominal);?></SPAN></P>
            </DIV>
            <DIV id="id1_2_2">
                <P class="p8 ft4">Surabaya, <?php
               echo date('d M Y', strtotime($datamaster->tanggal_pembayaran))?></P>
                <P class="p8 ft4">CREATIVE MEDIA</P>
            </DIV>
        </DIV>
        <DIV id="id1_3">
            <P class="p8 ft9">
                <?php if($datamaster->tempat_pembayaran == 'tubanan'){ ?>
                    Rida Annisa R.
                <?php } else { ?>
                    Dea Oktavia Putri A.
                <?php } ?>
                    
            </P>
            <P class="p8 ft4">Admin & Finance</P>
        </DIV>
    </DIV>
</BODY>

</HTML>